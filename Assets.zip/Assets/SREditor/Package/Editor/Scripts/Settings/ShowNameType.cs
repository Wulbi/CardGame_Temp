namespace SerializeReferenceEditor.Editor.Settings
{
	public enum ShowNameType
	{
		FullName,
		OnlyNameSpace,
		OnlyCurrentType
	}
}