using System;

namespace Demo
{
	[Serializable]
	public abstract class AbstractNamedData : AbstractData
	{
		public string DataName;
	}
}