﻿using System;

namespace Demo
{
	[Serializable]
	public abstract class AbstractData
	{
	}
}
