namespace Demo
{
	public interface IData
	{
		
	}
}