using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SANDamageGA : GameAction
{
    public int Amount;

    public SANDamageGA(int amount)
    {
        Amount = amount;
    }
}
