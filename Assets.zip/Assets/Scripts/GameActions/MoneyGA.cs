using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoneyGA : GameAction
{
    public int Amount;
    
    public MoneyGA(int amount)
    {
        Amount = amount;
    }
}
