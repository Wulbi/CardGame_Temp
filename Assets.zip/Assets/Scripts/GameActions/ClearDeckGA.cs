using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClearDeckGA : GameAction
{
    public ClearDeckGA() { }
}
