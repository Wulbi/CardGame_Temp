using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharmGA : GameAction
{
    public int Amount;
    
    public CharmGA(int amount)
    {
        Amount = amount;
    }
}
