using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum MapType
{
    CLASSROOM1,
    CLASSROOM2,
    STREET,
    ROOM,
    THERAPY,
    DREAM
}
